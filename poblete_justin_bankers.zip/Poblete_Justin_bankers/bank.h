//// Justin Poblete
//// CPSC 351
//// Prof McCarthy
//// 11/15/20
//// Bankers Algorithm Project

#ifndef bank_h
#define bank_h

#include <queue>

#include "customer.h"


class bank {
public:
  bank() = default;
  bank(const ext_vector<int>& available) : avail(available), customers() { }

  ext_vector<int> get_avail() const { return avail; }
  bool is_avail(const ext_vector<int>& req) const { return req < avail; }

  bool is_safe(int id, const ext_vector<int>& req) {
     if(!is_avail(req)) {return false;}   //if request isn't available, return false
     if(id > customers.size()) {std::cerr << "WARNING: id is out of range\n"; return false; } //if id is out of range, return false
     customer* temp = customers[id];  //create temp customer of current id in customers vector
     if(temp->needs_exceeded(req)) {return false;}  //if temp customer needs are more than request, then return false

     ext_vector<int> save_avail = avail;
     std::queue<int> qsafe;
     std::queue<customer*> qcustomers;

     for(customer* c : customers){    //queue of customers that haven't finished
       if((temp != c) && !c->needs_met()){
         qcustomers.push(c);
       }
     }
     withdraw_resources(req);     //simulate request 

     ext_vector<int> max_req;
     bool one_allocated = true; //check if allocation was successful

     while(!qcustomers.empty() && one_allocated){ //while there is a queue of customers that aren't finished and there is at least one allocation that occurs
       one_allocated = false;                     // loop through the queue until allocation isn't successful
       customer* c = qcustomers.front();
       qcustomers.pop();

       max_req = c->get_max();      //check if the max request can be matched
       if(is_avail(max_req)){       //if true then deposite resources and push safe customer id into the queue of safe customers
         deposit_resources(max_req);
         qsafe.push(c->get_id());
         one_allocated = true;
       }
       else {                       //if false then push back into queue of customers that arent finished
         qcustomers.push(c);
       }
     }
     avail = save_avail;            //update avail
     return qcustomers.empty();     //if there are no unfinished customers, then a safe path was made to satisfy all the processes if the request was granted
  }
  bool req_approved(int id, const ext_vector<int>& req) {
    std::cout << "random request: [" << req << " ]\n";
    std::cout << "Is this req available? " << Utils::yes_or_no(is_avail(req)) << "\n";
    std::cout << "     Is this req safe? " << Utils::yes_or_no(is_safe(id, req)) << "\n";
    if(is_safe(id,req)){
      std::cout << "------APPROVED------\n";
      return true;
    }
    else{
      std::cout << "------DENIED------\n";
      return false;
    }
  }

  void add_customer(customer* c) { customers.push_back(c); }

  void withdraw_resources(const ext_vector<int>& req) {
    if (!is_avail(req)) {
      pthread_mutex_lock(&mutex_);
      std::cerr << "WARNING: req: " << req << " is not available for withdrawing\n";
      pthread_mutex_unlock(&mutex_);
      return;
    }
    if (is_avail(req)) { avail -= req; }
  }
  void deposit_resources(const ext_vector<int>& req) { avail += req; }


  ext_vector<customer*> get_customers() const { return customers; }

  void show() const {
    pthread_mutex_lock(&mutex_);
    std::cout << "avail: [" << avail << "]\n";
    pthread_mutex_unlock(&mutex_);

    for (customer* c : customers) {
      c->show();
    }
    std::cout << "\n";
  }

  friend std::ostream& operator<<(std::ostream& os, const bank& be) {
    be.show();
    return os;
  }

private:
  ext_vector<int> avail;
  ext_vector<customer*> customers;
};

#endif /* bank_h */
